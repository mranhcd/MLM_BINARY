-- MySQL dump 10.16  Distrib 10.1.24-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: chudlzia_dm1
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bonus_date_logs`
--

DROP TABLE IF EXISTS `bonus_date_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bonus_date_logs` (
  `date` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bonus_date_logs`
--

LOCK TABLES `bonus_date_logs` WRITE;
/*!40000 ALTER TABLE `bonus_date_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `bonus_date_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devident_log`
--

DROP TABLE IF EXISTS `devident_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devident_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `nominal` float(255,0) DEFAULT NULL,
  `opendate` datetime DEFAULT NULL,
  `closedate` datetime DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devident_log`
--

LOCK TABLES `devident_log` WRITE;
/*!40000 ALTER TABLE `devident_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `devident_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devident_timeline`
--

DROP TABLE IF EXISTS `devident_timeline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devident_timeline` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `devident_id` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `percentage` float(10,3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devident_timeline`
--

LOCK TABLES `devident_timeline` WRITE;
/*!40000 ALTER TABLE `devident_timeline` DISABLE KEYS */;
/*!40000 ALTER TABLE `devident_timeline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fund_transaction`
--

DROP TABLE IF EXISTS `fund_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fund_transaction` (
  `date` datetime DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `nominal` float(255,3) DEFAULT NULL,
  `from_id` int(255) DEFAULT NULL COMMENT 'From User ID',
  `details` text,
  `to_id` int(255) DEFAULT NULL COMMENT 'To User ID',
  `trans_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`trans_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fund_transaction`
--

LOCK TABLES `fund_transaction` WRITE;
/*!40000 ALTER TABLE `fund_transaction` DISABLE KEYS */;
INSERT INTO `fund_transaction` (`date`, `type`, `nominal`, `from_id`, `details`, `to_id`, `trans_id`) VALUES ('2017-07-30 14:05:53',9,2.000,28,'REGISTRATION FOR USERNAME :DEMO1',0,1),('2017-07-30 14:05:53',1,2.000,0,'INITIAL COIN REGISTRATION',29,2),('2017-07-30 14:05:53',6,0.000,0,'BONUS FOR USERNAME <b>DEMO1</b> REGISTRATION',28,3),('2017-12-08 13:22:01',9,2.000,28,'REGISTRATION FOR USERNAME :DEMO2',0,4),('2017-12-08 13:22:01',1,2.000,0,'INITIAL COIN REGISTRATION',30,5),('2017-12-08 13:22:01',6,0.000,0,'BONUS FOR USERNAME <b>DEMO2</b> REGISTRATION',28,6),('2017-12-08 13:23:30',9,2.000,28,'REGISTRATION FOR USERNAME :DEMO3',0,7),('2017-12-08 13:23:30',1,2.000,0,'INITIAL COIN REGISTRATION',31,8),('2017-12-08 13:23:30',6,0.000,0,'BONUS FOR USERNAME <b>DEMO3</b> REGISTRATION',28,9),('2017-12-08 13:25:49',9,2.000,28,'REGISTRATION FOR USERNAME :DEMO4',0,10),('2017-12-08 13:25:49',1,2.000,0,'INITIAL COIN REGISTRATION',32,11),('2017-12-08 13:25:49',6,0.000,0,'BONUS FOR USERNAME <b>DEMO4</b> REGISTRATION',28,12);
/*!40000 ALTER TABLE `fund_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `genealogy`
--

DROP TABLE IF EXISTS `genealogy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `genealogy` (
  `uid` int(11) DEFAULT NULL,
  `parentid` int(11) DEFAULT NULL,
  `sponsorid` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `genealogy`
--

LOCK TABLES `genealogy` WRITE;
/*!40000 ALTER TABLE `genealogy` DISABLE KEYS */;
INSERT INTO `genealogy` (`uid`, `parentid`, `sponsorid`) VALUES (29,28,28),(30,28,28),(31,29,28),(32,30,28);
/*!40000 ALTER TABLE `genealogy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `holiday`
--

DROP TABLE IF EXISTS `holiday`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `holiday` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `holiday`
--

LOCK TABLES `holiday` WRITE;
/*!40000 ALTER TABLE `holiday` DISABLE KEYS */;
INSERT INTO `holiday` (`id`, `date`, `description`) VALUES (1,'2015-02-19','Imlek'),(2,'2015-03-21','Hari Raya Nyepi'),(3,'2015-04-03','Wafatnya Yesus Kristus ( Jumat Agung )'),(4,'2015-05-01','Hari Buruh International'),(5,'2015-05-14','Kenaikan Yesus Kristus'),(6,'2015-05-16','Israj Miraj'),(7,'2015-06-02','Hari Raya Waisak'),(8,'2015-07-17','Idul Fitri'),(9,'2015-07-18','Idul Fitri'),(10,'2015-08-17','Hari Kemerdekaan Indonesia'),(11,'2015-09-24','Idul Adha'),(12,'2015-10-14','Tahun Baru Islam 1437 Hijriyah'),(13,'2015-12-25','Hari Raya Natal');
/*!40000 ALTER TABLE `holiday` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_log`
--

DROP TABLE IF EXISTS `login_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uname` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=176 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_log`
--

LOCK TABLES `login_log` WRITE;
/*!40000 ALTER TABLE `login_log` DISABLE KEYS */;
INSERT INTO `login_log` (`id`, `uname`, `date`, `ip_address`, `status`) VALUES (1,'administrator','2017-07-01 12:37:39','113.22.115.73','SUCCESS'),(2,'administrator','2017-07-07 15:02:46','113.23.75.216','FAILED'),(3,'administrator','2017-07-07 15:02:53','113.23.75.216','SUCCESS'),(4,'administrator','2017-07-09 02:50:28','207.244.78.165','FAILED'),(5,'administrator','2017-07-09 02:50:46','207.244.78.165','SUCCESS'),(6,'administrator','2017-07-09 06:49:38','124.197.105.52','SUCCESS'),(7,'administrator','2017-07-09 23:51:38','70.189.181.89','SUCCESS'),(8,'administrator','2017-07-10 11:24:49','141.85.0.119','SUCCESS'),(9,'administrator','2017-07-11 05:15:45','42.112.144.15','SUCCESS'),(10,'administrator','2017-07-11 05:31:43','130.105.234.131','SUCCESS'),(11,'administrator','2017-07-16 12:01:18','14.162.156.249','SUCCESS'),(12,'administrator','2017-07-17 09:36:22','105.60.8.134','SUCCESS'),(13,'administrator','2017-07-18 06:04:58','222.153.175.85','SUCCESS'),(14,'administrator','2017-07-18 09:01:53','14.162.156.249','SUCCESS'),(15,'administrator','2017-07-18 18:54:06','125.237.146.114','SUCCESS'),(16,'administrator','2017-07-19 04:51:25','197.237.156.206','SUCCESS'),(17,'administraion','2017-07-22 17:03:49','125.239.152.34','FAILED'),(18,'administrator ','2017-07-22 17:04:02','125.239.152.34','FAILED'),(19,'administrator ','2017-07-22 17:04:15','125.239.152.34','FAILED'),(20,'administrator ','2017-07-22 17:04:26','125.239.152.34','SUCCESS'),(21,'Administrator','2017-07-28 12:25:09','174.238.144.171','SUCCESS'),(22,'Administrator','2017-07-28 12:25:12','174.238.144.171','SUCCESS'),(23,'administrator','2017-07-28 12:37:48','174.138.61.147','SUCCESS'),(24,'administrator','2017-07-28 15:37:06','174.138.61.147','SUCCESS'),(25,'demo','2017-07-30 13:51:33','160.242.134.120','FAILED'),(26,'demo','2017-07-30 13:51:34','160.242.134.120','FAILED'),(27,'demo','2017-07-30 13:53:08','160.242.134.120','FAILED'),(28,'demo','2017-07-30 14:04:08','42.112.242.250','FAILED'),(29,'administrator','2017-07-30 14:04:16','42.112.242.250','SUCCESS'),(30,'demo1','2017-07-30 14:07:04','160.242.134.120','FAILED'),(31,'demo1','2017-07-30 14:07:14','160.242.134.120','SUCCESS'),(32,'administrator','2017-07-30 14:09:02','160.242.134.120','SUCCESS'),(33,'Demo','2017-07-30 17:15:04','173.169.31.106','FAILED'),(34,'demo','2017-07-30 17:15:12','173.169.31.106','FAILED'),(35,'demo','2017-07-30 17:15:20','173.169.31.106','FAILED'),(36,'demo1','2017-07-31 10:53:14','123.24.168.54','SUCCESS'),(37,'administrator','2017-08-01 10:57:38','123.24.168.54','SUCCESS'),(38,'administrator','2017-08-02 23:29:42','42.114.142.151','SUCCESS'),(39,'demo','2017-08-05 04:58:15','180.191.103.63','FAILED'),(40,'demo1','2017-08-05 04:58:30','180.191.103.63','SUCCESS'),(41,'demo1','2017-08-05 04:58:32','180.191.103.63','SUCCESS'),(42,'administrator','2017-08-05 06:51:41','180.191.103.63','SUCCESS'),(43,'administrator','2017-08-05 07:07:41','180.191.103.63','SUCCESS'),(44,'demo1','2017-08-05 07:21:33','58.187.14.211','FAILED'),(45,'demo1','2017-08-05 07:21:52','58.187.14.211','SUCCESS'),(46,'administrator','2017-08-05 07:22:40','58.187.14.211','SUCCESS'),(47,'Demo1','2017-08-06 12:44:06','189.170.21.190','SUCCESS'),(48,'demo1','2017-08-06 15:29:17','189.170.21.190','FAILED'),(49,'demo1','2017-08-06 15:29:23','189.170.21.190','SUCCESS'),(50,'demo1','2017-08-07 00:13:52','189.170.21.190','SUCCESS'),(51,'administrator','2017-08-07 03:30:02','222.127.94.1','SUCCESS'),(52,'demo1','2017-08-07 03:32:43','222.127.94.8','SUCCESS'),(53,'Administrator','2017-08-07 03:34:52','112.198.101.138','FAILED'),(54,'Administrator','2017-08-07 03:34:59','112.198.101.138','SUCCESS'),(55,'Administrator','2017-08-07 03:35:02','112.198.101.138','SUCCESS'),(56,'Demo1','2017-08-08 02:39:30','67.140.35.77','SUCCESS'),(57,'Administrator','2017-08-10 23:35:01','200.76.83.165','SUCCESS'),(58,'Administrator','2017-08-10 23:35:04','200.76.83.159','SUCCESS'),(59,' test','2017-08-12 10:28:39','24.98.54.194','FAILED'),(60,'Demo1','2017-08-12 10:29:09','24.98.54.194','SUCCESS'),(61,'demo1','2017-08-15 17:25:14','189.173.134.152','SUCCESS'),(62,'demo1','2017-08-15 22:56:44','47.29.232.96','FAILED'),(63,'demo1','2017-08-15 22:56:58','47.29.232.96','SUCCESS'),(64,'demo1','2017-08-16 00:51:48','65.34.187.34','SUCCESS'),(65,'demo1','2017-08-18 23:55:06','105.112.41.244','SUCCESS'),(66,'demo1','2017-08-20 12:47:31','94.204.51.52','SUCCESS'),(67,'demo1','2017-08-21 01:06:32','105.11.32.154','SUCCESS'),(68,'Ademo','2017-08-22 01:06:10','41.190.14.208','FAILED'),(69,'demo1','2017-08-22 01:08:30','41.190.14.208','SUCCESS'),(70,'administrator','2017-08-22 14:16:57','41.190.12.92','SUCCESS'),(71,'administrator','2017-08-29 07:20:13','23.117.152.64','SUCCESS'),(72,'administrator','2017-09-01 09:35:05','179.218.71.67','SUCCESS'),(73,'demo1','2017-09-01 09:37:48','179.218.71.67','SUCCESS'),(74,'demo1','2017-09-04 06:37:07','49.44.51.42','SUCCESS'),(75,'demo1','2017-09-06 00:09:15','197.190.21.123','SUCCESS'),(76,'administrator','2017-09-12 12:17:49','70.175.19.34','SUCCESS'),(77,'demo1','2017-09-19 10:41:05','174.19.252.107','FAILED'),(78,'demo1','2017-09-19 10:41:19','174.19.252.107','SUCCESS'),(79,'administrator','2017-09-20 06:02:45','72.193.140.101','SUCCESS'),(80,'administrator','2017-09-20 06:37:15','72.193.140.101','SUCCESS'),(81,'demo1','2017-09-20 08:12:24','49.248.198.119','SUCCESS'),(82,'demo1','2017-09-20 16:09:23','93.40.190.36','SUCCESS'),(83,'administrator','2017-09-22 03:41:43','49.35.22.138','SUCCESS'),(84,'administrator','2017-10-02 07:31:52','118.189.200.156','SUCCESS'),(85,'administrator','2017-10-02 07:31:53','118.189.200.156','SUCCESS'),(86,'administrator','2017-10-02 07:31:55','118.189.200.156','SUCCESS'),(87,'demo1','2017-10-08 01:01:00','27.67.26.170','FAILED'),(88,'admin','2017-10-08 01:01:06','27.67.26.170','FAILED'),(89,'admin','2017-10-08 01:01:11','27.67.26.170','FAILED'),(90,'administrator','2017-10-08 01:01:28','27.67.26.170','SUCCESS'),(91,'demo1','2017-10-14 07:45:12','141.226.173.179','SUCCESS'),(92,'demo1','2017-10-14 15:09:35','213.162.68.69','SUCCESS'),(93,'administrator','2017-10-14 15:10:40','213.162.68.69','SUCCESS'),(94,'Demo1','2017-10-16 15:39:20','68.47.51.122','FAILED'),(95,'Demo1','2017-10-16 15:39:32','68.47.51.122','SUCCESS'),(96,'administrator','2017-10-22 21:47:12','118.70.185.249','SUCCESS'),(97,'demo1','2017-10-23 16:43:11','46.80.127.42','SUCCESS'),(98,'demo1','2017-10-27 00:22:09','181.174.141.1','SUCCESS'),(99,'demo1','2017-10-27 00:24:40','14.161.47.90','SUCCESS'),(100,'demo1','2017-10-27 02:42:15','58.84.33.106','SUCCESS'),(101,'administrator','2017-10-27 02:48:13','58.84.33.106','SUCCESS'),(102,'demo1','2017-10-29 12:38:28','181.174.141.1','SUCCESS'),(103,'administrator','2017-10-29 12:40:07','181.174.141.1','SUCCESS'),(104,'admin','2017-11-02 10:22:19','76.185.46.14','FAILED'),(105,'admin','2017-11-02 10:23:05','76.185.46.14','FAILED'),(106,'admin','2017-11-05 07:00:31','113.23.74.161','FAILED'),(107,'admin','2017-11-05 07:00:37','113.23.74.161','FAILED'),(108,'admin','2017-11-05 07:00:43','113.23.74.161','FAILED'),(109,'admin','2017-11-05 07:00:47','113.23.74.161','FAILED'),(110,'administrator','2017-11-05 07:01:06','113.23.74.161','SUCCESS'),(111,'administrator','2017-11-05 09:41:45','76.185.46.14','SUCCESS'),(112,'Demo1','2017-11-06 09:25:08','96.255.212.159','SUCCESS'),(113,'demo1 ','2017-11-10 07:19:30','154.118.80.149','SUCCESS'),(114,'demo1','2017-11-10 11:15:43','41.202.219.66','SUCCESS'),(115,'demo1','2017-11-16 00:02:18','66.25.208.202','FAILED'),(116,'administrator','2017-11-16 00:03:06','66.25.208.202','SUCCESS'),(117,'demo1','2017-11-24 06:25:43','81.11.196.104','SUCCESS'),(118,'demo1','2017-12-04 10:45:06','129.0.40.233','SUCCESS'),(119,'demo1','2017-12-05 01:52:11','41.215.173.92','FAILED'),(120,'demo1','2017-12-05 01:52:21','41.215.173.92','SUCCESS'),(121,'administrator','2017-12-05 01:57:51','41.215.173.92','SUCCESS'),(122,'administrator','2017-12-08 13:19:51','42.112.188.239','SUCCESS'),(123,'demo1','2017-12-09 05:30:12','129.0.40.232','SUCCESS'),(124,'demo1','2017-12-16 07:10:36','72.229.252.49','SUCCESS'),(125,'demo1','2017-12-16 13:09:27','197.211.56.130','SUCCESS'),(126,'demo1','2017-12-19 22:40:12','67.140.35.77','SUCCESS'),(127,'administrator','2017-12-19 23:17:56','14.231.217.43','SUCCESS'),(128,'administrator','2017-12-20 00:37:44','14.231.217.43','SUCCESS'),(129,'demo1','2017-12-21 05:21:16','83.134.112.114','SUCCESS'),(130,'administrator','2017-12-22 22:53:50','123.24.172.247','SUCCESS'),(131,'ntmnd93','2017-12-23 02:08:53','123.24.172.247','FAILED'),(132,'ntmnd94@gmail.com','2017-12-23 02:09:22','123.24.172.247','FAILED'),(133,'demo1','2017-12-24 22:36:20','174.210.14.14','SUCCESS'),(134,'demo1','2017-12-24 22:36:23','174.210.14.14','SUCCESS'),(135,'administrator','2017-12-25 00:48:40','47.156.75.16','SUCCESS'),(136,'Demo1','2017-12-25 06:20:20','173.20.197.116','FAILED'),(137,'Demo1','2017-12-25 06:20:25','173.20.197.116','SUCCESS'),(138,'demo1','2017-12-25 13:12:01','45.255.128.232','SUCCESS'),(139,'administrator','2017-12-25 13:13:11','45.255.128.232','SUCCESS'),(140,'administrator','2017-12-26 19:12:03','173.20.197.116','SUCCESS'),(141,'demo1','2018-01-03 04:12:53','184.5.90.122','SUCCESS'),(142,'administrator','2018-01-03 04:16:47','184.5.90.122','SUCCESS'),(143,'administrator','2018-01-03 09:07:54','60.243.37.112','SUCCESS'),(144,'demo1','2018-01-10 16:04:09','98.166.218.249','FAILED'),(145,'demo1','2018-01-10 16:04:20','98.166.218.249','SUCCESS'),(146,'demo1','2018-01-17 13:07:38','41.90.58.215','FAILED'),(147,'demo1','2018-01-17 13:07:42','41.90.58.215','FAILED'),(148,'administrator','2018-01-17 13:08:12','41.90.58.215','SUCCESS'),(149,'demo1','2018-01-19 13:36:22','184.5.90.122','SUCCESS'),(150,'administrator','2018-01-19 13:37:39','184.5.90.122','SUCCESS'),(151,'demo1','2018-01-25 11:49:58','108.250.228.13','SUCCESS'),(152,'demo1','2018-01-27 10:23:16','175.142.198.93','SUCCESS'),(153,'administrator','2018-01-27 10:24:58','175.142.198.93','SUCCESS'),(154,' demo1','2018-01-27 13:17:34','107.197.39.145','FAILED'),(155,'demo1','2018-01-27 13:18:16','107.197.39.145','SUCCESS'),(156,'administrator','2018-01-27 13:19:36','107.197.39.145','SUCCESS'),(157,'demo','2018-01-27 15:38:01','197.210.172.63','FAILED'),(158,'demo1','2018-01-27 15:38:13','197.210.172.63','SUCCESS'),(159,'administrator','2018-01-27 15:41:59','197.210.172.63','SUCCESS'),(160,'administrator','2018-01-30 05:01:39','107.197.39.145','SUCCESS'),(161,'administrator','2018-01-30 13:37:37','107.197.39.145','SUCCESS'),(162,'Demo1','2018-02-05 22:57:12','113.210.66.136','SUCCESS'),(163,'Demo1','2018-02-05 22:57:13','113.210.66.136','SUCCESS'),(164,'demo1','2018-02-05 23:45:05','199.65.210.6','SUCCESS'),(165,'demo1','2018-02-05 23:47:29','199.65.210.6','SUCCESS'),(166,'Administrator','2018-02-07 09:40:53','175.139.64.44','SUCCESS'),(167,'demo1','2018-02-07 10:40:13','103.209.88.35','SUCCESS'),(168,'Demo1','2018-02-08 00:49:43','107.77.169.9','SUCCESS'),(169,'demo1','2018-02-10 06:33:18','175.156.231.65','SUCCESS'),(170,'demo1','2018-02-12 01:33:14','113.193.123.190','SUCCESS'),(171,'demo1','2018-02-16 01:31:13','14.162.161.81','SUCCESS'),(172,'demo1','2018-02-18 06:26:42','115.134.102.6','SUCCESS'),(173,'demo1','2018-02-18 06:26:44','115.134.102.6','SUCCESS'),(174,'demo1','2018-02-18 21:43:55','108.35.150.39','SUCCESS'),(175,'demo1','2018-02-18 23:55:26','108.35.150.39','SUCCESS');
/*!40000 ALTER TABLE `login_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pairing_log`
--

DROP TABLE IF EXISTS `pairing_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pairing_log` (
  `idUser` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `left` float(255,0) DEFAULT NULL,
  `right` float(255,0) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pairing_log`
--

LOCK TABLES `pairing_log` WRITE;
/*!40000 ALTER TABLE `pairing_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `pairing_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paypal_invoice`
--

DROP TABLE IF EXISTS `paypal_invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paypal_invoice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` varchar(200) NOT NULL,
  `status` int(11) NOT NULL COMMENT '1 COMPLETED 0 PENDING',
  `date` datetime NOT NULL,
  `buyer` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `amount` float(255,3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paypal_invoice`
--

LOCK TABLES `paypal_invoice` WRITE;
/*!40000 ALTER TABLE `paypal_invoice` DISABLE KEYS */;
/*!40000 ALTER TABLE `paypal_invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) DEFAULT NULL,
  `value` float DEFAULT NULL,
  `devident_rate` varchar(255) DEFAULT NULL,
  `max_pairing` float(255,0) DEFAULT NULL,
  `reward` int(11) DEFAULT NULL,
  `referral_rate` int(255) DEFAULT NULL,
  `disable` int(255) DEFAULT '0',
  PRIMARY KEY (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` (`product_id`, `product_name`, `value`, `devident_rate`, `max_pairing`, `reward`, `referral_rate`, `disable`) VALUES (1,'METAL',0,'1.25/0.50',100,0,8,1),(2,'BRONZE',500,'1.25/0.50',500,1,9,1),(3,'SILVER',1000,'1.25/0.50',1000,1,10,1),(4,'GOLD',5000,'1.25/0.50',5000,1,11,1),(5,'PLATINUM',10000,'3',7500,1,13,1),(6,'DIAMOND',50000,'1.25/0.50',25000,1,15,1),(26,'Tour',2,'1/3',2,NULL,10,0);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(2550) DEFAULT NULL,
  `value` varchar(2550) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `type_transaction`
--

DROP TABLE IF EXISTS `type_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `type_transaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `type_transaction`
--

LOCK TABLES `type_transaction` WRITE;
/*!40000 ALTER TABLE `type_transaction` DISABLE KEYS */;
INSERT INTO `type_transaction` (`id`, `name`) VALUES (1,'TRANSFER'),(2,'FUND TO REGISTER FUND  CONVERSION'),(3,'REGISTER DEVIDENT'),(4,'PAIRING BONUS'),(5,'DEVIDENT BONUS'),(6,'SPONSOR BONUS'),(7,'DEVIDENT CLOSING'),(8,'WITHDRAWAL DEDUCTION ( FUNDS )'),(9,'NEW MEMBER FEE ( DEDUCT FROM REGISTER FUND )'),(10,'TRANSFER REGISTER FUND');
/*!40000 ALTER TABLE `type_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_bank`
--

DROP TABLE IF EXISTS `user_bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_bank` (
  `uid` int(11) NOT NULL,
  `bank_name` varchar(255) NOT NULL,
  `branch_name` varchar(255) NOT NULL,
  `acnumber` varchar(255) NOT NULL,
  `bankholder` varchar(255) DEFAULT NULL,
  `swiftcode` varchar(255) DEFAULT NULL,
  `bank_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`bank_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_bank`
--

LOCK TABLES `user_bank` WRITE;
/*!40000 ALTER TABLE `user_bank` DISABLE KEYS */;
INSERT INTO `user_bank` (`uid`, `bank_name`, `branch_name`, `acnumber`, `bankholder`, `swiftcode`, `bank_id`) VALUES (29,'Demo1','','12345678','Demo1','Demo1',1),(30,'aaa','','23423423423423','aaaaaaaaa','aaaa',2),(31,'wwwwwwww','','23413123123','wwwww','wwwwwww',3),(32,'demo4','','2314123123','demo4','demo4',4);
/*!40000 ALTER TABLE `user_bank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_detail`
--

DROP TABLE IF EXISTS `user_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_detail` (
  `uid` int(30) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `email` varchar(40) NOT NULL,
  `mobile` text NOT NULL,
  `phone` text NOT NULL,
  `state` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `zip` text NOT NULL,
  `address` text NOT NULL,
  `relation` varchar(255) NOT NULL,
  `country` varchar(255) DEFAULT NULL,
  `beneficiary` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_detail`
--

LOCK TABLES `user_detail` WRITE;
/*!40000 ALTER TABLE `user_detail` DISABLE KEYS */;
INSERT INTO `user_detail` (`uid`, `first_name`, `last_name`, `gender`, `email`, `mobile`, `phone`, `state`, `city`, `zip`, `address`, `relation`, `country`, `beneficiary`) VALUES (29,'Dmo','Demo','MALE','demo@demo.com','','','Demo','Demo','Demo','Demo','Demo','Demo','DEMO'),(30,'demo2','demo2','MALE','demo2@demo2.com','','','aa','aaaa','Ã¢aaaa','aaaa','aaaaa','aaa','AAAAA'),(31,'wwwwwwww','wwww','MALE','demo3@demo3.com','','','wwww','wwww','ww','wwww','wwwwww','wwwwww','WWWWWWW'),(32,'demo4','demo4','MALE','demo4@demo4.com','','','demo4','demo4','demo4','demo4','demo4','demo4','DEMO4');
/*!40000 ALTER TABLE `user_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_id`
--

DROP TABLE IF EXISTS `user_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_id` (
  `uname` varchar(25) NOT NULL,
  `password` varchar(60) NOT NULL,
  `pin` varchar(60) NOT NULL,
  `register_date` date NOT NULL,
  `role` int(255) NOT NULL,
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `product` int(255) DEFAULT NULL,
  `banned` int(11) DEFAULT '0',
  `paired` int(255) DEFAULT '0',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_id`
--

LOCK TABLES `user_id` WRITE;
/*!40000 ALTER TABLE `user_id` DISABLE KEYS */;
INSERT INTO `user_id` (`uname`, `password`, `pin`, `register_date`, `role`, `uid`, `product`, `banned`, `paired`) VALUES ('administrator','200ceb26807d6bf99fd6f4f0d1ca54d4','e10adc3949ba59abbe56e057f20f883e','2015-01-09',0,28,0,0,1),('demo1','25d55ad283aa400af464c76d713c07ad','e10adc3949ba59abbe56e057f20f883e','2017-07-30',1,29,26,0,0),('demo2','25d55ad283aa400af464c76d713c07ad','','2017-12-08',1,30,26,0,0),('demo3','25d55ad283aa400af464c76d713c07ad','','2017-12-08',1,31,26,0,0),('demo4','25d55ad283aa400af464c76d713c07ad','','2017-12-08',1,32,26,1,0);
/*!40000 ALTER TABLE `user_id` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `withdrawal`
--

DROP TABLE IF EXISTS `withdrawal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `withdrawal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `nominal` varchar(255) DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `paid_date` datetime DEFAULT NULL,
  `pendregs` float(255,3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `withdrawal`
--

LOCK TABLES `withdrawal` WRITE;
/*!40000 ALTER TABLE `withdrawal` DISABLE KEYS */;
INSERT INTO `withdrawal` (`id`, `uid`, `date`, `nominal`, `bank_id`, `status`, `paid_date`, `pendregs`) VALUES (16,2,'2015-01-12 12:54:34','75',19,'PAID','2015-01-12 13:20:56',25.000),(17,12,'2015-01-15 16:21:32','168.75',22,'PAID','2015-03-03 05:49:40',56.250),(18,17,'2015-01-16 17:05:55','75',25,'PAID','2015-01-16 17:11:05',25.000),(19,17,'2015-01-16 17:06:17','75',25,'PAID','2015-01-16 17:16:45',25.000),(20,17,'2015-01-16 17:07:00','75',25,'PAID','2015-01-16 17:19:13',25.000),(21,17,'2015-01-17 10:43:02','75',25,'PAID','2015-01-17 13:05:26',25.000),(22,17,'2015-01-17 10:43:23','75',25,'PAID','2015-01-17 13:06:43',25.000),(23,17,'2015-01-17 10:44:41','75',25,'PAID','2015-01-17 13:07:38',25.000),(24,24,'2015-01-17 10:47:54','75',18,'PAID','2015-01-17 10:53:44',25.000);
/*!40000 ALTER TABLE `withdrawal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'chudlzia_dm1'
--

--
-- Dumping routines for database 'chudlzia_dm1'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-02-22 14:54:15
