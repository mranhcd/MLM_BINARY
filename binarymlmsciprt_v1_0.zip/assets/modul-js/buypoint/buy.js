var Script = function () {

    $.validator.setDefaults({
        submitHandler: function() { 
           var amount=$("#amount").val();
           //var types=$("#type").val();
           var dataString = 'amount='+amount;
           
             $.ajax({
                type: "POST",
                url: "/buypoints/build",
                data: dataString,
                cache: false,
                beforeSend: function(){ 
                    $("#submitpaypal").hide();
                    $("#waitingpaypal").show();
                    $("#suksesupdate").hide();
                    $("#gagalupdate").hide();
                },
                complete: function(e, xhr, settings){
                    if(e.status === 200){
                        $("#waitingpaypal").text("Redirecting to Paypal");
                        //$("#suksesupdate").show();
                        setTimeout(function() {
                            window.location.href=e.responseText;
                        }, 2000);
                    }else{
                        $("#submitpaypal").show();
                        $("#waitingpaypal").hide();
                        //$("#suksesupdate").show();
                        $("#gagalupdate").show();
                    }
                }
            }); 
        }
    });

    $().ready(function() {
        $("#buypoint").validate({
            rules: {
                amount: {
                    required: true,
                    min: 50,
                    digits: true
                },
            },
            messages: {
                
                amount: {
                    required: "You must specified how much you want to buy",
                    min: "Minimum is $50USD",
                    digits: "Amount must be numerical ONLY"
                },
                
                
            }
        });

        // propose username by combining first- and lastname
       
    });


}();